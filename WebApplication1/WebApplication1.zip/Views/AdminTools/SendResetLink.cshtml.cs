using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Views.AdminTools
{
    public class SendResetLinkModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
